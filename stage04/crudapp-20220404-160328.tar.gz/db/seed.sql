INSERT INTO employees
  (name, address, salary)
VALUES
  ('Nikon lenses change', '21 Main St. E', '200'),
  ('Canon', '22 Main St. E', '201'),
  ('Fuji Film', '21 Jump St. W', '202'),
  ('WTF Cameras', '22 Jump St. W', '203');
